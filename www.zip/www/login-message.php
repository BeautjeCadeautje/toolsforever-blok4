<main>
    <div class="container">
        <h4>
            <?php echo $_GET['message'] == 'wrongpassword' ? 'Wachtwoord is onjuist' : 'Gebruiker niet gevonden' ?>
        </h4>
    </div>
</main>