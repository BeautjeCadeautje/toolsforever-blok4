# Tools4ever

## Project Description

Tools4ever is a web application that allows users to view and purchase tools.

## Technologies Used

- HTML
- CSS
- JavaScript
- PHP
- MySQL

## Features

- View tools
- Add tools
- View users
- Add users
- View brands
- Login
- Logout


## Installation

1. Clone the repository
2. Run `docker compose up -d`
3. Go to localhost:8080 and run the SQL file in the sql folder in phpMyAdmin
4. Go to localhost and see the website

